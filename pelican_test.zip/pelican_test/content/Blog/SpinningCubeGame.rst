SpinningCube game
#################

:date: 2017-5-9 22:00

.. unitywebgl:: SpinningCube
	:width: 320
	:height: 240